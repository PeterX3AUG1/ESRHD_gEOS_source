% ����-DS��ʱ��仯������
clear,clc
data1 = load('tolEntr_1Ddensity400_RRK_ES5_T376_SO.txt');
t1 = data1(:,1); S1 = data1(:,2);
data2 = load('tolEntr_1Ddensity200_RRK_ES5_T376_SO.txt');
t2 = data2(:,1); S2 = data2(:,2);
data3 = load('tolEntr_1Ddensity100_RRK_ES5_T376_SO.txt');
t3 = data3(:,1); S3 = data3(:,2);
% data4 = load('tolEntr_1DSmooth320_EOS_3_ES5.txt');
% t4 = data4(:,1); S4 = data4(:,2);
plot(t1,S1,'k-','linewidth',2)
hold on
plot(t2,S2,'r-.','linewidth',2)
plot(t3,S3,'b:','linewidth',2)
% plot(t4,S4,'r--','linewidth',3)
% ylim([-3.6e-5,0.3e-5])
% yt=-3.5e-5:0.5e-5:0;
% set(gca,'ytick',yt);
% legend("EC6: $320$ grids","ES5: $320$ grids",'location','southwest','interpreter','latex')
% legend("EC6: $80$ grids","ES5: $80$ grids","ES5: $160$ grids","ES5: $320$ grids",'location','southwest','interpreter','latex')
legend('$400$ grids','$200$ grids','$100$ grids','location','northeast','interpreter','latex')
print -depsc2 RHD_tolEntr_1Ddensity_ES5_RRK_EOS_1.eps