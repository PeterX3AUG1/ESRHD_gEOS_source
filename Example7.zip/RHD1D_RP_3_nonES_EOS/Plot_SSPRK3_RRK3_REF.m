% Use MATLAB to plot numerical solutions based on data obtained by C/C++ code 
clear,clc
% data = load('RM1DP2T6.dat');
data1 = load('RP_3_priU_RK3_EOS_1_ES5_400.dat');
data2 = load('RP_3_priU_RK3_EOS_1_nonES5_400_24sin76t01.dat');
data_num = load('RP_3_priU_RK3_EOS_1_LF_100000.dat');

%% parameters
xmin = 0; xmax = 1;
T = 0.4;
Nx = 400;
Nx_num = 100000;
gpn = 3;
dx = (xmax - xmin)/Nx;
dx_num = (xmax - xmin)/Nx_num;
xe = (xmin-(gpn-0.5)*dx):dx:(xmax+(gpn-0.4)*dx); % ��N+6���㣬�ҳ�ȥ��β6�����ⵥԪ�ĵ㣬������Ϊ��Ԫ�е㣬������������ĵ�Ԫƽ��ֵ
xe_num = (xmin-(gpn-0.5)*dx_num):dx_num:(xmax+(gpn-0.4)*dx_num);

%% numerical solutions through C/C++ data
r = data1(:,1); 
u = data1(:,2);
p = data1(:,3);
rRRK = data2(:,1); 
uRRK = data2(:,2);
pRRK = data2(:,3);
r_num = data_num(:,1);
u_num = data_num(:,2);
p_num = data_num(:,3);

gamma = 4/3;

% r = r(1+gpn+1:end-gpn-1);
% u = u(1+gpn+1:end-gpn-1);
% p = p(1+gpn+1:end-gpn-1);

%% Plots
figure(1)
plot(xe(1+gpn:end-gpn),r,'bo','markersize',4)
hold on
plot(xe(1+gpn:end-gpn),rRRK,'rs','markersize',4)
plot(xe_num(1+gpn:end-gpn),r_num,'k-','linewidth',2)
axis square
% legend('ES5 solution','reference solution','location','northeast','fontsize',6);
% xlim([0.5 0.53])
% print -depsc2 RHD1D_RP_3_CMP_EOS1_density_nonES.eps
figure(2)
plot(xe(1+gpn:end-gpn),u,'bo','markersize',4)
hold on
plot(xe(1+gpn:end-gpn),uRRK,'rs','markersize',4)
plot(xe_num(1+gpn:end-gpn),u_num,'k-','linewidth',2)
axis square
% legend('ES5 solution','reference solution','location','northeast','fontsize',6)
% xlim([0.5 0.53])
% print -depsc2 RHD1D_RP_3_CMP_EOS1_velocity_nonES.eps
figure(3)
plot(xe(1+gpn:end-gpn),p,'bo','markersize',4)
hold on
plot(xe(1+gpn:end-gpn),pRRK,'rs','markersize',4)
plot(xe_num(1+gpn:end-gpn),p_num,'k-','linewidth',2)
axis square
% legend('ES5 solution','reference solution','location','northeast','fontsize',6)
% xlim([0.5 0.53])
% print -depsc2 RHD1D_RP_3_CMP_EOS1_pressure_nonES.eps